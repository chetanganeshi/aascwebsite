    <!-- Javascript Files
    ================================================== -->

    <!-- initialize jQuery Library -->
    <script src="assets/js/jquery.min-1.11.1.js"></script>
    <!-- Preloader js file -->
    <script src="assets/js/queryloader2.min.js" type="text/javascript"></script>
    <!-- For smooth animatin  -->
    <script src="assets/js/wow.min.js"></script>  
    <!-- Bootstrap js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- slick slider -->
    <script src="assets/js/slick.min.js"></script>
    <!-- superslides slider -->
    <script src="assets/js/jquery.easing.1.3.js"></script>
    <script src="assets/js/jquery.animate-enhanced.min.js"></script>
    <script src="assets/js/jquery.superslides.min.js" type="text/javascript" charset="utf-8"></script>   
    <!-- for circle counter -->
    <script src='assets/js/jquery.circliful.min.js'></script>
    <!-- Gallery slider -->
    <script type="text/javascript" language="javascript" src="assets/js/jquery.tosrus.min.all.js"></script>   
   
    <!-- Custom js-->
    <script src="assets/js/custom.js"></script>

    <!-- jAlert -->
<script src="assets/js/jAlert.js"></script>
<script src="assets/js/jAlert-functions.js"></script>
<script src="assets/js/jquery-confirm.js"></script>